﻿namespace Ex03.GarageLogic.Enum
{
    public class CarDoorsEnum
    {
        public enum eCarDoors
        {
            Two = 1,
            Three,
            Four,
            Five,
        }
    }

    public class Copy1OfCarDoorsEnum
    {
        public enum eCarDoors
        {
            Two = 1,
            Three,
            Four,
            Five,
        }
    }

    public class CopyOfCopy1OfCarDoorsEnum
    {
        public enum eCarDoors
        {
            Two = 1,
            Three,
            Four,
            Five,
        }
    }

    public class CopyOfCarDoorsEnum
    {
        public enum eCarDoors
        {
            Two = 1,
            Three,
            Four,
            Five,
        }
    }
}
