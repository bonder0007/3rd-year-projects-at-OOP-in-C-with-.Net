﻿namespace Ex03.GarageLogic.Enum
{
    // $G$ CSS-019 (-5) Bad enumeration class/file name (should be in the form of ePascalCased as well).

    public class VehicleTypeEnum
    {
        public enum eVehicleType
        {
            Car = 1,
            Motorcycle,
            Truck,
        }
    }

    public class Copy1OfVehicleTypeEnum
    {
        public enum eVehicleType
        {
            Car = 1,
            Motorcycle,
            Truck,
        }
    }

    public class CopyOfVehicleTypeEnum
    {
        public enum eVehicleType
        {
            Car = 1,
            Motorcycle,
            Truck,
        }
    }
}
