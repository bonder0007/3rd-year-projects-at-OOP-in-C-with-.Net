﻿namespace Ex03.GarageLogic.Enum
{
    public class EngineTypeEnum
    {
        public enum eEngineType
        {
            Fuel = 1,
            Electric,
        }
    }

    public class Copy1OfEngineTypeEnum
    {
        public enum eEngineType
        {
            Fuel = 1,
            Electric,
        }
    }

    public class CopyOfEngineTypeEnum
    {
        public enum eEngineType
        {
            Fuel = 1,
            Electric,
        }
    }
}
