﻿namespace CheckersGame
{
    // $G$ SFN-013 (+4) Bonus: UI features.
    public class Program
    {
        public static void Main()
        {
            SettingsForm settingsForm = new SettingsForm();
            settingsForm.ShowDialog();        
        }
    }
}
