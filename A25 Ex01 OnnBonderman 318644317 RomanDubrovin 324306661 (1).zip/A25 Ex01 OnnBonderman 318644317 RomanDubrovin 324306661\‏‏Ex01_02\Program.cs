﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Ex01_02
{
    // $G$ CSS-999 (0) The Classes must have an access modifier.
    class Program
    {
        public static void Main()
        {
            int heightOfTree = 7;
            PrintTree(heightOfTree);
        }
        // $G$ DSN-003 (-5) The code should be divided to methods. 
        // $G$ CSS-027 (0) Missing blank line.
        public static void PrintTree(int i_heightOfTree)
        {
            char currentChar = 'A';
            // $G$ CSS-027 (0) Missing blank line.
            for (int index = 1; index <= i_heightOfTree - 2; index++)
            {
                Console.Write(index + " ");
                for (int linesForSpaces = 0; linesForSpaces < i_heightOfTree - index - 1; linesForSpaces++)
                {
                    Console.Write("  ");
                }
                // $G$ CSS-027 (0) Missing blank line.
                for (int charsForLines = 0; charsForLines < 2 * index - 1; charsForLines++)
                {
                    Console.Write(currentChar + " ");
                    if (currentChar == 'Z')
                    {
                        currentChar = 'A';
                    }
                    else
                    {
                        currentChar++;
                    }
                }

                Console.WriteLine();
            }
            // $G$ CSS-027 (0) Missing blank line.
            Console.Write(i_heightOfTree - 1 + "  ");
            for (int spaces = 0; spaces < i_heightOfTree - 3; spaces++)
            {
                Console.Write("  ");
            }
            // $G$ CSS-027 (0) Missing blank line.
            Console.WriteLine("|{0}|",currentChar);
            // $G$ CSS-027 (0) Unnecessary blank lines.



            Console.Write(i_heightOfTree + "  ");
            for (int spaces = 0; spaces < i_heightOfTree - 3; spaces++)
            {
                Console.Write("  ");
            }
            // $G$ CSS-027 (0) Missing blank line.
            Console.WriteLine("|{0}|",currentChar);
        }
    }
}















