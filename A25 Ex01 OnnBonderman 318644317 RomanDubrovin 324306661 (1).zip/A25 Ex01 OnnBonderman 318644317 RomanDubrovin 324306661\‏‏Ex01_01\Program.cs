﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex01_01
{
    // $G$ CSS-999 (0) The Classes must have an access modifier.
    // $G$ DSN-006 (-20) Main method should only call the main method of the program
    // $G$ RUL-005 (-20) Wrong zip folder structure, the zip file should contain a single folder.
    // $G$ CSS-027 (-3) Spaces are not kept as required.
    // $G$ NTT-999 (-10) You should have used Environment.NewLine instead of "\n".
    // $G$ CSS-027 (-8) Unnecessary blank lines.
    // $G$ DSN-999 (-15) There is no good reason to define all the methods as public.
    // $G$ CSS-027 (-8) Missing blank lines.
    // $G$ NTT-006 (-10) You should have used StringBuilder.
    // $G$ NTT-001 (-10) You should have used string.Format.
    // $G$ SFN-003 (-5) The program does not cope properly with invalid input.
    class Program
    {
        static void Main()
        {
            List <int> integerNumber = new List<int>();
            List<string> binaryNumbers = new List<string>();
            int helpWithConvertStringToInt=0;
            int LongestBitSeries = 0;
           Console.WriteLine("enter 3 numbers of 8 digit each\n press enter after each number");

            while(integerNumber.Count < 3)
            {
                string binaryInput = Console.ReadLine();
                helpWithConvertStringToInt = int.Parse(binaryInput);
                if (IsValidNumber(binaryInput))
                {

                    integerNumber.Add(ConvertBinaryToInteger(helpWithConvertStringToInt));
                    binaryNumbers.Add(binaryInput);
                }
                else
                {
                    Console.WriteLine("Invalid number, enter 8 digits of 1/0 ONLY!");
                }
            }

            //ascending order
            integerNumber.Sort();
            Console.WriteLine("These are the numbers by ascending order");
            for (int index = 0; index < integerNumber.Count; index++)
            {
                Console.Write(" " + integerNumber[index] + " ");
            }

            //average sum
            float average = (float)integerNumber.Average();
            Console.WriteLine("\n\nThe average value for the numbers is {0}" , average);

            //size of binary series
             FindingLongestBitSeries(binaryNumbers);


            //number Of Switches in every binary number 
            for (int index = 0; index < binaryNumbers.Count; index++)
            {
                NumberOfSwitchesInBinaryNumber(binaryNumbers[index]);
            }

            //finding LongestZeros and SmallestOnes
            FindingMinMaxOnesZerosEachBinary(binaryNumbers);

        }

        // $G$ CSS-013 (-10) Bad parameters names (should be in the form of i_PascalCase). Applicable to the entire project
        // $G$ CSS-007 (-5) Missing blank line, after "for" block.
        public static void NumberOfSwitchesInBinaryNumber(string i_binaryNumber)
        {
            int countSwitches = 0;
            for(int index = 1;index < i_binaryNumber.Length;index ++)
            {
                if (i_binaryNumber[index] != i_binaryNumber[index - 1])
                {
                    countSwitches++;
                }
            }
            Console.WriteLine("\nThe binary Number ({0})  has ({1}) switches ", i_binaryNumber, countSwitches);
        }
        // $G$ CSS-999 (-4) Missing blank line between methods.
        // $G$ NTT-999 (-1) You should have used string.Empty instead of "".
        public static void FindingMinMaxOnesZerosEachBinary(List<string>i_binaryNumber)
        {
            int minOnes = 8;
            int maxZeros = 0;
            string numberWithMinOnes = "";
            string numberWithMaxZeros = "";

            for(int index = 0;index < i_binaryNumber.Count;index++)
            {
                string tempStringBinaryNumber = i_binaryNumber[index];

                int zeroCount = 0;
                int oneCount = 0;

                for (int indexTwo = 0; indexTwo < tempStringBinaryNumber.Length; indexTwo++)
                {
                    if (tempStringBinaryNumber[indexTwo] == '0')
                    {
                        zeroCount++;
                    }
                    else if (tempStringBinaryNumber[indexTwo] == '1')
                    {
                        oneCount++;
                    }
                }
                
                if (zeroCount > maxZeros)
                {
                    maxZeros = zeroCount;
                    numberWithMaxZeros = i_binaryNumber[index];
                }

                if (oneCount < minOnes)
                {
                    minOnes = oneCount;
                    numberWithMinOnes = i_binaryNumber[index];
                }
            }
            int tempForMaxBinary = int.Parse(numberWithMaxZeros);
            int tempForMixBinary = int.Parse(numberWithMinOnes);
            Console.WriteLine("\n The number with the longest Zeros is "+ ConvertBinaryToInteger(tempForMaxBinary) + " (" + numberWithMaxZeros + ")with (" + maxZeros + ")zeros");
            Console.WriteLine("\n The number with the smallest Ones is "+ ConvertBinaryToInteger(tempForMixBinary) + " (" + numberWithMinOnes + ")with (" + minOnes + ")ones");
        }




        public static void FindingLongestBitSeries(List<string>i_binaryNumber)
        {
            int overAllMaxLength = 0;
            string numberWithLongestSequence = "";

            foreach (var binaryNumber in i_binaryNumber)
            {
                int maxLength = 0;
                int currentLength = 1;
                char currentBinaryChar = binaryNumber[0];

                for (int index = 1; index < binaryNumber.Length; index++)
                {
                    if (binaryNumber[index] == currentBinaryChar)
                    {
                        currentLength++;
                    }
                    else
                    {
                        currentBinaryChar = binaryNumber[index];
                        maxLength = Math.Max(maxLength, currentLength);
                        currentLength = 1;
                    }
                }
                maxLength = Math.Max(maxLength, currentLength);

                
                if (maxLength > overAllMaxLength)
                {
                    overAllMaxLength = maxLength;
                    numberWithLongestSequence = binaryNumber;
                }
            }
            Console.WriteLine("\nThe binary number with the longest bit sequence is: " + numberWithLongestSequence);
            Console.WriteLine("The longest sequence length is: " + overAllMaxLength);
        }

        // $G$ CSS-028 (-6) A method should not include more than one return statement.s
        public static bool IsValidNumber(string i_seriesBinaryDigits)
        {
            if (i_seriesBinaryDigits.Length != 8)
            {
                return false;
            }

            for (int index = 0; index < i_seriesBinaryDigits.Length; index++)
            {
                int resultNumber = (i_seriesBinaryDigits[index] - '0');
                if (resultNumber != 1 && resultNumber != 0)
                {
                    return false;
                }

            }
            return true;
        }
        public static int ConvertBinaryToInteger(int i_binaryNumber)
        {
            int index;
            int output_sum = 0;
            int counter8Digits = 8;
            for (index = 0; index < counter8Digits; index++)
            {
                if (i_binaryNumber % 10 == 1)
                {
                    output_sum = (int)(Math.Pow(2, index)) + output_sum;
                }
                i_binaryNumber /= 10;
            }
            return output_sum;
        }

    }
}
