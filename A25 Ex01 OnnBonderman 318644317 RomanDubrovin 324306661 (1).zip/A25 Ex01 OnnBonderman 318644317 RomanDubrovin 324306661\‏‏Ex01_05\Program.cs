﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex01_05
{
    // $G$ CSS-999 (0) The Classes must have an access modifier.
    class Program
    {
        // $G$ DSN-003 (-5) The code should be divided to methods. 
        // $G$ DSN-006 (0) Main method should only call the main method of the program
        // $G$ CSS-027 (-2) Unnecessary blank lines.
        // $G$ SFN-024 (-5) The program does not correctly calculate the number of digit pairs in the number.
        static void Main()
        {
            Console.WriteLine("Enter 9 digits number please");
            string i_numberFromUser = Console.ReadLine();

            while(IsValidNumber(i_numberFromUser)==false)
            {
                Console.WriteLine("Wrong input, Enter 9 digits number please");
                i_numberFromUser = Console.ReadLine();
            }
            
            Console.WriteLine("The total number that larger then the unity digit is {0}",LargerThenUnityDigit(i_numberFromUser));
            
            int numberAfterConvertFromString = int.Parse(i_numberFromUser);
            Console.WriteLine("The total number of divided digits by 4 is {0}", IsdivideBy4(i_numberFromUser));

            float difference = (float)FindingMaxDigit(numberAfterConvertFromString) / (float)FindingMinDigitWithoutZero(numberAfterConvertFromString);
            Console.WriteLine("The ratio between the max digit ({0}) to the min digit ({1}) is {2}",
            FindingMaxDigit(numberAfterConvertFromString), FindingMinDigitWithoutZero(numberAfterConvertFromString),difference);

            int[] coupleArray = CountingHowManyCouples(i_numberFromUser);
            int totalPairs = 0;
            for (int index = 0; index < coupleArray.Length; index++)
            {
               
                if (coupleArray[index] > 1)
                {
                    int pairs = coupleArray[index] * (coupleArray[index] - 1) / 2;
                    totalPairs += pairs;
                    Console.WriteLine("Digit {0} has {1} pair ",index,pairs);
                }
            }
            // $G$ CSS-027 (0) Missing blank line.
            Console.WriteLine("Total number of pairs: {0}", totalPairs);
            // $G$ CSS-027 (0) Unnecessary blank line.

        }

        public static int[] CountingHowManyCouples(string i_string)
        {
            int[] arr = new int [10];

            for(int index=0;index<i_string.Length;index++)
            {
                arr[i_string[index]-'0']++;
            }
            return arr;
        }
        // $G$ CSS-028 (0) A method should not include more than one return statement.
        public static int FindingMinDigitWithoutZero(int i_number)
        {
            int o_minDigit = 9;
            bool flagForOnlyZero = true;

            while (i_number > 0)
            {
                flagForOnlyZero = false;
                int Unitydigit = i_number % 10;
                if ((Unitydigit <= o_minDigit) && (Unitydigit !=0))
                {
                    o_minDigit = Unitydigit;
                }
                i_number /= 10;

            }
            if(flagForOnlyZero)
            {
                return 0;
            }

            return o_minDigit;

        }
        public static int FindingMaxDigit(int i_number)
        {
            int o_maxDigit = 0;

            while(i_number>0)
            {
                int Unitydigit = i_number % 10;
                if(Unitydigit >= o_maxDigit)
                {
                    o_maxDigit = Unitydigit;
                }
                i_number /= 10;

            }
            return o_maxDigit;
        }
        // $G$ CSS-026 (-3) Bad code indentation.
        public static int IsdivideBy4(string i_string)
        {
            int o_counterOfDivideDigits = 0;

        for(int index=0;index<i_string.Length;index++)
            {
                int result = i_string[index] - '0';
                if(result %4==0)
                {
                    o_counterOfDivideDigits++;
                }
            }
            return o_counterOfDivideDigits;

        }
        public static int LargerThenUnityDigit(string i_stringNumber)
        {
            int o_counterOfLargerDigits = 0;
            char UnityDigit = i_stringNumber[i_stringNumber.Length-1];
            for(int index =(i_stringNumber.Length-1);index>=0;index--)
            {
                if(UnityDigit< i_stringNumber[index])
                {
                    o_counterOfLargerDigits++;
                }
            }
            return o_counterOfLargerDigits;
        }
        public static bool IsValidNumber(string i_number)
        {
            if (i_number.Length != 9)
            {
                return false;
            }
            else
            {
                for(int index=0;index<i_number.Length;index++)
                {
                    if((Char.IsDigit(i_number[index]) != true))
                    {
                        return false;
                    }
                }
            }
            return true;

        }
    }
}
