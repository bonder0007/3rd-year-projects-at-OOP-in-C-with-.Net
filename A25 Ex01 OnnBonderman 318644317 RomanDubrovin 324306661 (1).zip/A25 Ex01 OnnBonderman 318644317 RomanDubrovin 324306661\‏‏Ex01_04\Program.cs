﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex01_04
{
    // $G$ CSS-999 (0) The Classes must have an access modifier.
    class Program
    {
        // $G$ DSN-003 (-5) The code should be divided to methods. 
        // $G$ DSN-006 (0) Main method should only call the main method of the program
        static void Main()
        {
            Console.WriteLine("Hello, please enter a string of 10 chars only letters or only numbers");
            string i_stringFromUser = Console.ReadLine();

            while((IsValidString(i_stringFromUser))==false)
            {
                Console.WriteLine("You have entered wrong input, please try again");
                i_stringFromUser = Console.ReadLine();
            }


            if(checkPalindrome(i_stringFromUser))
            {
                Console.WriteLine("The string is Palindrome");
            }
            else
            {
                Console.WriteLine("Sorry, The string is NOT Palindrome");
            }

            if(IsLettersString(i_stringFromUser))
            {
                Console.WriteLine("There are {0} lower letters in the string",HowManyLowerLetters(i_stringFromUser));
                
                if(IsDescendingString(i_stringFromUser))
                {
                    Console.WriteLine("The string is a DescendingString");
                }
                else
                {
                    Console.WriteLine("The string is NOT a DescendingString");
                }
            }
            else
            {
                if(IsNumberDivisibleBy4(i_stringFromUser))
                {
                    Console.WriteLine("The number is divisible by 4 ");
                }
                else
                {
                    Console.WriteLine("The number is NOT divisible by 4");
                }
            }
        }

        // $G$ SFN-016 (-5) The program does not display if is Divisible By Four for inputs bigger then int32 as "9876543210".
        // $G$ CSS-028 (0) A method should not include more than one return statement.
        public static bool IsNumberDivisibleBy4(string i_stringToCheck)
        {
            int result = int.Parse(i_stringToCheck);
            if (result % 4 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static int HowManyLowerLetters(string i_stringToCheck)
        {
            int counterOfLowerLetters = 0;
            for(int index =0;index< i_stringToCheck.Length;index++)
            {
                if(i_stringToCheck[index] >='a' && (i_stringToCheck[index]<='z'))
                {
                    counterOfLowerLetters++;
                }
            }
            return counterOfLowerLetters;
        }
        // $G$ CSS-028 (0) A method should not include more than one return statement.
        public static bool IsDescendingString(string i_stringToCheck)
        {
            for(int index=1;index<i_stringToCheck.Length;index++)
            {
                if (i_stringToCheck[index] >= i_stringToCheck[index - 1])
                    return false;

            }
            return true;
        }
        // $G$ CSS-028 (0) A method should not include more than one return statement.
        public static bool IsLettersString(string i_stringToCheck)
        {
            if(char.IsLetter(i_stringToCheck[0]))
            {
                return true;
            }
            return false;
        }
        // $G$ CSS-028 (0) A method should not include more than one return statement.
        public static bool checkPalindrome(string i_string)
        {
            int left_index = 0;
            int right_index = i_string.Length - 1;
            while (left_index < right_index)
            {
                if (i_string[left_index] == i_string[right_index])
                {
                    left_index++;
                    right_index--;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }
        // $G$ CSS-028 (0) A method should not include more than one return statement.
        public static bool IsValidString(string i_stringToCheck)
        {
            if (i_stringToCheck.Length != 10)
            {
                return false;
            }

            for(int index=1;index < i_stringToCheck.Length;index++)
            {
                if(           char.IsDigit(i_stringToCheck[index]) != char.IsDigit(i_stringToCheck[index-1])  ||            
                             char.IsLetter(i_stringToCheck[index]) != char.IsLetter(i_stringToCheck[index - 1]) )
                {
                    return false;
                }
            }
            return true;
        }
    }
}
