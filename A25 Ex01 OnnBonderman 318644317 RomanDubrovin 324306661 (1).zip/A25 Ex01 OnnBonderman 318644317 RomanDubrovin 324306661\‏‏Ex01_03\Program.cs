﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex01_03
{
    // $G$ CSS-999 (0) The Classes must have an access modifier.
    class Program
    {
        // $G$ DSN-006 (0) Main method should only call the main method of the program
        // $G$ CSS-008 (-3) Missing blank line, after "while" and "for" blocks.
        // $G$ SFN-012 (-5) The program does not cope properly with invalid input, what about letters?
        // $G$ SFN-011 (-5) The program does not print correctly a tree with a height >= than 10.
        public static void Main()
        {
            Console.WriteLine("Enter the height that you want, should be between 3-15:\n ");
            string inputHeight = Console.ReadLine();
            int convertHeight = 0;

            while ((int.TryParse(inputHeight, out convertHeight) &&
                      (convertHeight >= 3 && convertHeight <= 15) == false))
            {
                Console.WriteLine("Wrong input, try again please");
                inputHeight = Console.ReadLine();
            }
            PrintTree(convertHeight);
        }

        // $G$ DSN-003 (-5) The code should be divided to methods. 
        public static void PrintTree(int i_heightOfTree)
        {
            char currentChar = 'A';

            for (int index = 1; index <= i_heightOfTree - 2; index++)
            {
                Console.Write(index + " ");
                for (int linesForSpaces = 0; linesForSpaces < i_heightOfTree - index - 1; linesForSpaces++)
                {
                    Console.Write("  ");
                }

                for (int charsForLines = 0; charsForLines < 2 * index - 1; charsForLines++)
                {
                    Console.Write(currentChar + " ");
                    if (currentChar == 'Z')
                    {
                        currentChar = 'A';
                    }
                    else
                    {
                        currentChar++;
                    }
                }

                Console.WriteLine();
            }

            Console.Write(i_heightOfTree - 1 + "  ");
            for (int spaces = 0; spaces < i_heightOfTree - 3; spaces++)
            {
                Console.Write("  ");
            }
            Console.WriteLine("|{0}|",currentChar);

            Console.Write(i_heightOfTree + "  ");
            for (int spaces = 0; spaces < i_heightOfTree - 3; spaces++)
            {
                Console.Write("  ");
            }
            Console.WriteLine("|{0}|",currentChar);
        }
    }

}














