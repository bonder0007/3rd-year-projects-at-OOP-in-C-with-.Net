﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CheckersGame
{
    public class Move
    {
        private Position m_From;
        private Position m_To;

        public Move(Position i_From, Position i_To)
        {
            m_From = i_From;
            m_To = i_To;
        }

        // $G$ DSN-003 (-5) This method is too long. 
        public static Move ProcessMove(string i_UserInput, Player i_Player, Board i_Board, Position i_LastEaterPosition)
        {
            char playerKingSymbol = (i_Player.GetSymbol() == 'O') ? 'U' : 'K';
            Piece[,] ezerMatrix = Board.GetPieceMatrix();
            char startRow = i_UserInput[0];
            char startCol = i_UserInput[1];
            char endRow = i_UserInput[3];
            char endCol = i_UserInput[4];

            int startColIndex = startCol - 'a';
            int startRowIndex = startRow - 'A';
            int endColIndex = endCol - 'a';
            int endRowIndex = endRow - 'A';

            if (startColIndex < 0 || startColIndex >= Board.GetSize() ||
                endColIndex < 0 || endColIndex >= Board.GetSize() ||
                startRowIndex < 0 || startRowIndex >= Board.GetSize() ||
                endRowIndex < 0 || endRowIndex >= Board.GetSize())
            {
                throw new ArgumentException("Out of bounds.");
            }

            Position startPos = new Position(startRowIndex, startColIndex);
            Position endPos = new Position(endRowIndex, endColIndex);

            if (ezerMatrix[startRowIndex, startColIndex].GetSymbol() == i_Player.GetSymbol() ||
                ezerMatrix[startRowIndex, startColIndex].GetSymbol() == playerKingSymbol)
            {
                if(ezerMatrix[endPos.GetRow(),endPos.GetColumn()].GetSymbol() != ' ')
                {
                    throw new ArgumentException("End Target isnt avalible");
                }

                if (i_LastEaterPosition != null && !startPos.Equals(i_LastEaterPosition))
                {
                    throw new ArgumentException("You must continue eating with the same piece.");
                }

                if (CheckforBackwoards(startPos, endPos,
                         ezerMatrix[startPos.GetRow(), startPos.GetColumn()].GetSymbol()))
                {
                    throw new ArgumentException("Ilegal Move ! Cannot move backwards");
                }

                if (CheckMoveEatable(startPos, endPos, i_Player, i_Board))
                {
                    Console.WriteLine("Move is an eating move.");
                    Board.UpdateBoardForEatingMove(startPos, endPos);
                    if (Board.CanContinueEatingFrom(endPos, i_Player.GetSymbol(), playerKingSymbol))
                    {
                        i_LastEaterPosition = endPos;
                    }
                    else
                    {
                        i_LastEaterPosition = null;
                    }
                }
                else if (CheckMoveTooFar(startPos, endPos))
                {
                    throw new ArgumentException("Move too far.");
                }
                else if (!CheckMoveIsEmpty(endPos))
                {
                    throw new ArgumentException("End position is not free.");
                }
                else if (!CheckMoveDiagonal(startPos, endPos))
                {
                    throw new ArgumentException("Not diagonal.");
                }
            }
            else
            {
                throw new ArgumentException("Wrong Player you Chose to Move! pick one of your players");
            }
           
            return new Move(startPos, endPos);
        }

        public static bool CheckMoveEatable(Position i_StartPos, Position i_EndPos, Player i_Player, Board i_Board) 
        {
            if (CheckMoveforEatable(i_StartPos, i_EndPos))
            {
                Piece[,] boardPieces = Board.GetPieceMatrix();
                char startSymbol = boardPieces[i_StartPos.GetRow(), i_StartPos.GetColumn()].GetSymbol();
                int middleRow = (i_StartPos.GetRow() + i_EndPos.GetRow()) / 2;
                int middleCol = (i_StartPos.GetColumn() + i_EndPos.GetColumn()) / 2;

                int ezer_EndRow = 0, ezer_Endcol = 0;
                ezer_EndRow = i_EndPos.GetRow();
                ezer_Endcol = i_EndPos.GetColumn();
                Piece middlePiece = boardPieces[middleRow, middleCol];
                Piece targetPiece = boardPieces[ezer_EndRow, ezer_Endcol];

                if ("XOKU".Contains(boardPieces[i_StartPos.GetRow(),i_StartPos.GetColumn()].GetSymbol()))
                {
                    if ((startSymbol == 'X' || startSymbol == 'O') && (!CheckforBackwoards(i_StartPos, i_EndPos, startSymbol)))
                    {
                        return true;
                    }

                      char middleSymbol = middlePiece.GetSymbol();
                      char targetSymbol = targetPiece.GetSymbol();

                    if (targetSymbol == ' ' &&
                       ((middleSymbol == 'O' && startSymbol != 'U') ||
                        (middleSymbol == 'X' && startSymbol != 'K') ||
                        (middleSymbol == 'K' && startSymbol != 'X') ||
                        (middleSymbol == 'U' && startSymbol != 'O')))
                    {
                         return true;
                    }
                }
            }
          
            return false;
        }

        private static bool CheckMoveDiagonal(Position i_StartPos, Position i_EndPos)
        {
            return (Math.Abs(i_StartPos.GetRow() - i_EndPos.GetRow()) == 1 &&
                   Math.Abs(i_StartPos.GetColumn() - i_EndPos.GetColumn()) == 1) ||
                   (Math.Abs(i_StartPos.GetRow() - i_EndPos.GetRow()) == 2 &&
                   Math.Abs(i_StartPos.GetColumn() - i_EndPos.GetColumn()) == 2);
        }

        private static bool CheckMoveforEatable(Position i_StartPos, Position i_EndPos)
        {
            return Math.Abs(i_StartPos.GetRow() - i_EndPos.GetRow()) == 2  &&
                   Math.Abs(i_StartPos.GetColumn() - i_EndPos.GetColumn()) ==2 ;
        }

        private static bool CheckMoveTooFar(Position i_StartPos, Position i_EndPos)
        {
            return Math.Abs(i_StartPos.GetRow() - i_EndPos.GetRow()) > 1 &&
                   Math.Abs(i_StartPos.GetColumn() - i_EndPos.GetColumn()) > 1;
        }

        public static bool CheckforBackwoards(Position i_StartPos, Position i_EndPos, char i_PieceSymbol)
        {
            if(i_PieceSymbol == 'K' || i_PieceSymbol == 'U')
            {
                return false;
            }


            if (i_PieceSymbol == 'X')
            {
                if (i_StartPos.GetRow() > i_EndPos.GetRow())
                {
                    return false;
                }
            }
            else if (i_PieceSymbol == 'O')
            {
                if (i_StartPos.GetRow() < i_EndPos.GetRow())
                {
                    return false;
                }
            }
            else
            {
                return true;
            }

            return true;
        }
       
        private static bool CheckMoveIsEmpty(Position i_EndPos)
        {
            Piece[,] ezerPiece = Board.GetPieceMatrix();
            Piece targetPiece = ezerPiece[i_EndPos.GetRow(), i_EndPos.GetColumn()];
            return targetPiece == null || targetPiece.GetSymbol() == ' ';     
        }

        public Position GetFrom()
        {
            return m_From;
        }

        public Position GetTo()
        {
            return m_To;
        }

        // $G$ DSN-001 (-2) This method should belong to the UI class
        public static void printEatingMoves(List <Move> i_Moves)
        {
            if (i_Moves.Count != 0)
            {
                Console.WriteLine("You have to choose one of those moves: ");
                for (int index = 0; index < i_Moves.Count; index++)
                {
                    Position ezerFirst =i_Moves[index].GetFrom();
                    Position ezerSecond = i_Moves[index].GetTo();

                    Position.PrintPositionInLetters(ezerFirst);
                    Console.Write(">");
                    Position.PrintPositionInLetters(ezerSecond);
                    Console.WriteLine();
                }
            }
        }
    }
}
