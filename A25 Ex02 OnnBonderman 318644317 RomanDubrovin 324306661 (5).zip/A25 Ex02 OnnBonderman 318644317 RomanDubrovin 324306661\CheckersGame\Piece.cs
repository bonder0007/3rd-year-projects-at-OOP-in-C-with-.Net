﻿
namespace CheckersGame
{

    public class Piece
    {
        private char m_Symbol;

        public Piece(char i_Symbol)
        {
            m_Symbol = i_Symbol;
        }

        // $G$ DSN-007 (-5) You should use properties, not Get\Set methods...
        public char GetSymbol()
        {
            return m_Symbol;
        }

        public void SetSymbol(char i_symbol) 
        {
            m_Symbol = i_symbol;
        }

    }

}
