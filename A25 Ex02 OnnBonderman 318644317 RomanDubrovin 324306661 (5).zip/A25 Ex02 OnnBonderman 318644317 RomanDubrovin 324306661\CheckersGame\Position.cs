﻿using System;

namespace CheckersGame
{
    public class Position
    {
        private int m_Row;
        private int m_Column;

        public Position(int i_Row, int i_Column)
        {
            m_Row = i_Row;
            m_Column = i_Column;
        }

        public int GetRow()
        {
            return m_Row;
        }

        public int GetColumn()
        {
            return m_Column;
        }

        public bool Equals(Position i_OtherPosition)
        {
            return m_Row == i_OtherPosition.GetRow() && m_Column == i_OtherPosition.GetColumn();
        }

        // $G$ DSN-001 (-2) This method should belong to the UI class
        public static void PrintPositionInLetters(Position i_PositionToPrint)
        {
            char rowLetter = (char)(i_PositionToPrint.GetRow() + 'A');
            char colLetter = (char)(i_PositionToPrint.GetColumn() + 'a');
            Console.Write($"{rowLetter}{colLetter}");
        }
    }
}
