﻿using System;
using Ex02.ConsoleUtils;

namespace CheckersGame
{
    public static class ConsoleUI
    {
        public static void StartGameUI()
        {
            Player[] players;
            bool isVsComputer;

            Console.WriteLine("Welcome to Checkers Game!" + Environment.NewLine);
            Console.Write("Enter Player 1 name: ");
            string player1Name = Console.ReadLine();

            while((Player.ValidationName(player1Name)))
            {
                Console.WriteLine("wrong input, write less then 20 characters and without spaces"
                    + Environment.NewLine);
                Console.Write("Enter Player 1 name: ");
                player1Name = Console.ReadLine();
            }

            Player player1 = new Player(player1Name, 'X');
            Console.Write("Do you want to play against a computer? (yes/no): ");
            string playAgainstComputer = Console.ReadLine().ToLower();

            while(!(ValidationAnswerForVsPC(playAgainstComputer)))
            {
                Console.WriteLine("enter only yes/no, please try again");
                playAgainstComputer = Console.ReadLine().ToLower();
            }

            if (playAgainstComputer == "yes")
            {
                players = new Player[] { player1, new Player("Computer", 'O') };
                isVsComputer = true;
            }
            else
            {
                Console.Write("Enter Player 2 name: ");
                string player2Name = Console.ReadLine();

                while ((Player.ValidationName(player2Name)))
                {
                    Console.WriteLine("wrong input, write less then 20 characters and without spaces"
                        + Environment.NewLine);
                    Console.Write("Enter Player 2 name: ");
                    player2Name = Console.ReadLine();
                }

                Player player2 = new Player(player2Name, 'O');
                players = new Player[] { player1, player2 };
                isVsComputer = false;
            }

            string sizeBoard = Board.GetBoardSizeFromUser();
            int convertStringSizeBoardToNumber = int.Parse(sizeBoard);
            GameManager gameManager = new GameManager();
            gameManager.StartGameLogical(convertStringSizeBoardToNumber, players, isVsComputer);
        }

        public static void EndGame()
        {
            do
            {
                Console.Write("The game is over. Would you like another try?  (yes/no): ");
                string userAnswer = Console.ReadLine().ToLower();

                if (userAnswer.Equals("yes"))
                {
                    GameManager NewRound = new GameManager();
                    Screen.Clear();
                    NewRound.StartGameLogical(Board.GetSize(), GameManager.GetPlayers(), GameManager.GetIsVsComputer());
                }
                else if (userAnswer.Equals("no"))
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Invalid input. Please type yes/no " + Environment.NewLine);
                }
            } while (true);
        }

        public static Move GetPlayerMove(Player i_Player, Board i_Board, Position i_LastEaterPosition)
        {
            string ezerUserInput;
            Move ezermove = null;
            Player[] ezerPlayers = GameManager.GetPlayers();
            int opponentIndex = (Array.IndexOf(ezerPlayers, i_Player) + 1) % 2;

            while (true)
            {
                Console.WriteLine($"{i_Player.GetName()}'s turn: ");
                ezerUserInput = Console.ReadLine();
                if(ezerUserInput.Equals("Q"))
                {
                    GameManager.CalcScore(ezerPlayers, i_Player.GetSymbol());
                    EndGame();
                }

                if (!IsMoveValid(ezerUserInput))
                {
                    Console.WriteLine("Wrong input, the format is Fa>Fb for example, please try again.");
                    continue;
                }         
                try
                {
                    ezermove = Move.ProcessMove(ezerUserInput, i_Player, i_Board, i_LastEaterPosition);
                    break;
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"Invalid move: {ex.Message}. Please try again.");
                }
            }

            return ezermove;
        }

        public static bool ValidateMoveInputFormat(string i_UserInput)
        {
            return((i_UserInput.Length == 5) && (i_UserInput[2] == '>'));
        }

        public static bool IsMoveValid(string i_UserInput)
        {
            return (ValidateMoveInputFormat(i_UserInput)) &&
                (i_UserInput[0] >= 'A' && i_UserInput[0] <= 'J' && i_UserInput[1] >= 'a' && i_UserInput[1] <= 'j' &&
                 i_UserInput[3] >= 'A' && i_UserInput[3] <= 'J' && i_UserInput[4] >= 'a' && i_UserInput[4] <= 'j' &&
                 i_UserInput[2] == '>');
        }
        private static bool ValidationAnswerForVsPC(string i_CheckAnswer)
        {
            return i_CheckAnswer == "yes" || i_CheckAnswer == "no";
        }
    }
}
