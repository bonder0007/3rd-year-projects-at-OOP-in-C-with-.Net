﻿using System;
using System.Collections.Generic;
using Ex02.ConsoleUtils;

namespace CheckersGame
{
    public class Board
    {
        // $G$ CSS-002 (-3) Bad members variable name (should be in the form of m_PascalCase).
        private static int m_s_Size;
        private static Piece[,] m_s_Pieces;

        public Board(int i_Size)
        {
            m_s_Size = i_Size;
            m_s_Pieces = new Piece[i_Size, i_Size];
        }

        public static int GetSize()
        {
            return m_s_Size;
        }

        public void Initialize()
        {
            InitializePieces();
            DrawBoard();
        }

        // $G$ CSS-028 (-6) method shouldn't include more then one return command.
        // $G$ CSS-001 (-8) Bad variable name (should be in the form of camelCase
        public static bool CheckIfThereAreMovesLeft(Board i_Board, Player i_CurrentPlayer)
        {
            char playerKingSymbol = (i_CurrentPlayer.GetSymbol() == 'O') ? 'U' : 'K';
            int counterPiecePerPlayer = 0;
            bool noOtherMove = false;
            for (int row = 0; row < m_s_Size; row++)
            {
                for (int col = 0; col < m_s_Size; col++)
                {
                    if ((m_s_Pieces[row, col].GetSymbol() == i_CurrentPlayer.GetSymbol() ||
                        m_s_Pieces[row, col].GetSymbol() == playerKingSymbol))
                    {
                        counterPiecePerPlayer++;
                        Position CurrentPosition = new Position(row, col);
                        List<Move> DirectionsToEat = 
                            checkDirectionsForEating(CurrentPosition, i_CurrentPlayer.GetSymbol(), playerKingSymbol);
                        List<Move> IsThereLegalMoves = GetLegalMovesForPosition(CurrentPosition);
                        if (DirectionsToEat.Count != 0  || IsThereLegalMoves.Count != 0)
                        {
                            noOtherMove = false;
                            return noOtherMove;
                        }
                        else
                        {
                            noOtherMove = true;
                        }
                    }
                }
            }

            if (counterPiecePerPlayer == 0)
            {
                return true;
            }

            return noOtherMove;
        }

        public static List<Move> GetLegalMovesForPosition(Position i_CurrentPosition)
        {
            List<Move> legalMoves = new List<Move>();
            int currentRow = i_CurrentPosition.GetRow();
            int currentCol = i_CurrentPosition.GetColumn();
            int endLimitDueToSymbol = 0;
            int startLimit = 0;

            int[] rowOffsets = { -1, -1, 1, 1 }; 
            int[] colOffsets = { -1, 1, -1, 1 };

            if (m_s_Pieces[currentRow, currentCol].GetSymbol() == 'K' ||
                m_s_Pieces[currentRow, currentCol].GetSymbol() == 'U')
            {
                endLimitDueToSymbol = 4;
            }
            else if (m_s_Pieces[currentRow, currentCol].GetSymbol() == 'X')
            {
                endLimitDueToSymbol = 2;
            }
            else
            {
                endLimitDueToSymbol = 4;
                startLimit = 2;

            }

            for (int index = startLimit; index < endLimitDueToSymbol; index++) 
            {
                int newRow = currentRow + rowOffsets[index];
                int newCol = currentCol + colOffsets[index];

                if (newRow >= 0 && newRow < Board.GetSize() && newCol >= 0 && newCol < Board.GetSize())
                {
                    if (m_s_Pieces[newRow, newCol].GetSymbol() == ' ')
                    {
                        Position ezerCurrentPosition = new Position(currentRow, currentCol);
                        Position ezerNewPosition = new Position(newRow, newCol);
                        Move ezerNewLegalMove = new Move(ezerCurrentPosition, ezerNewPosition);
                        legalMoves.Add(ezerNewLegalMove);
                    }
                }
            }

            return legalMoves;
        }

        // $G$ CSS-999 (-5) Public methods should start with an uppercase letter
        public static List<Move> checkIfPossibleEatingMoves(Board i_Board, char i_CharPlayerSmybol)
        {
            char playerKingSymbol = (i_CharPlayerSmybol == 'O') ? 'U' : 'K';
            List<Move> FinalAllMovesToEat = new List<Move>();
            for (int row = 0; row < m_s_Size; row++)
            {
                for (int col = 0; col < m_s_Size; col++)
                { 
                    if ((m_s_Pieces[row, col].GetSymbol() == i_CharPlayerSmybol) ||
                         m_s_Pieces[row, col].GetSymbol() == playerKingSymbol)
                    {
                        Position ezerPosition = new Position(row, col);
                        if (CanContinueEatingFrom(ezerPosition, i_CharPlayerSmybol,playerKingSymbol))
                        {
                            List<Move> PossibleMovesToEat = checkDirectionsForEating(ezerPosition, i_CharPlayerSmybol, playerKingSymbol);
                            for (int index = 0; index < PossibleMovesToEat.Count; index++)
                            {
                                FinalAllMovesToEat.Add(PossibleMovesToEat[index]);
                            }
                        }
                    }
                }
            }

            return FinalAllMovesToEat;
        }

        private static List<Move> checkDirectionsForEating(Position i_CheckPositionToEating, char i_PlayerSymbol, char i_PlayerKingSymbol)
        {
            int[][] directions = null;
            Piece[,] ezerMatrixPiece = Board.GetPieceMatrix();
            char currentPieceSymbol = 
            ezerMatrixPiece[i_CheckPositionToEating.GetRow(), i_CheckPositionToEating.GetColumn()].GetSymbol();
            List<Move> ListOfEatingMoves = new List<Move>();
            if (currentPieceSymbol == 'K' || currentPieceSymbol == 'U')
            {
                directions = new int[][]
                {
                    new int[] { -2, -2 }, 
                    new int[] { -2, 2 },  
                    new int[] { 2, -2 },  
                    new int[] { 2, 2 }    
                };
            }
            else if (currentPieceSymbol == 'X')
            {
                directions = new int[][]
                {
                    new int[] { -2, -2 }, 
                    new int[] { -2, 2 }   
                };
            }
            else
            {
                directions = new int[][]
                {
                    new int[] { 2, -2 },  
                    new int[] { 2, 2 }    
                };
            }

            foreach (var direction in directions)
            {
                int newRow = i_CheckPositionToEating.GetRow() + direction[0];
                int newCol = i_CheckPositionToEating.GetColumn() + direction[1];
                int middleRow = i_CheckPositionToEating.GetRow() + direction[0] / 2;
                int middleCol = i_CheckPositionToEating.GetColumn() + direction[1] / 2;

                if (IsWithinBounds(newRow, newCol))
                {
                    if (m_s_Pieces[middleRow, middleCol].GetSymbol() != i_PlayerSymbol &&
                        m_s_Pieces[middleRow, middleCol].GetSymbol() != i_PlayerKingSymbol &&
                        m_s_Pieces[middleRow, middleCol].GetSymbol() != ' ' &&
                        m_s_Pieces[newRow, newCol].GetSymbol() == ' ')
                    {
                        Position FinalPosition = new Position(newRow, newCol);
                        Move ezerMove = new Move(i_CheckPositionToEating, FinalPosition);
                        ListOfEatingMoves.Add(ezerMove);
                    }
                }
            }

            return ListOfEatingMoves;
        }

        private void InitializePieces()
        {
            for (int row = 0; row < m_s_Size; row++)
            {
                for (int col = 0; col < m_s_Size; col++)
                {
                    if ((row < m_s_Size / 2 - 1) && (row + col) % 2 == 1)
                    {
                        m_s_Pieces[row, col] = new Piece('O');
                    }
                    else if ((row >= m_s_Size / 2 + 1) && (row + col) % 2 == 1)
                    {
                        m_s_Pieces[row, col] = new Piece('X');
                    }
                    else
                    {
                        m_s_Pieces[row, col] = new Piece(' ');
                    }
                }
            }
        }

        private void DrawBoard()
        {
            Console.Write("  ");
            for (char col = 'a'; col < 'a' + m_s_Size; col++)
            {
                Console.Write($" {col}  ");
            }

            Console.WriteLine();
            Console.WriteLine(new string('=', m_s_Size * 4 + 2));
            for (int row = 0; row < m_s_Size; row++)
            {
                char rowLabel = (char)('A' + row);
                Console.Write($"{rowLabel}|");

                for (int col = 0; col < m_s_Size; col++)
                {
                    if (m_s_Pieces[row, col] == null)
                    {
                        Console.Write("   |");
                    }
                    else
                    {
                        Console.Write($" {m_s_Pieces[row, col].GetSymbol()} |");
                    }
                }

                Console.WriteLine();
                Console.WriteLine(new string('=', m_s_Size * 4 + 2));
            }
        }

        public static string GetBoardSizeFromUser()
        {
            string ezerSize = string.Empty;
            Console.WriteLine("Enter the size of the board that you want, the options are 6,8,10 only");
            ezerSize = Console.ReadLine();

            while (!(ValidationBoardSize(ezerSize)))
            {
                Console.WriteLine("Wrong number, the options are 6,8,10 only, try again");
                ezerSize = Console.ReadLine();
            }

            return ezerSize;
        }

        private static bool ValidationBoardSize(string i_BoardSize)
        {
            int boardSizeEzer = int.Parse(i_BoardSize);

            return boardSizeEzer == 6 || boardSizeEzer == 8 || boardSizeEzer == 10;
        }

        public void PrintBoard()
        {
            Screen.Clear();
            Console.Write("  ");

            for (char col = 'a'; col < 'a' + m_s_Size; col++)
            {
                Console.Write($" {col}  ");
            }

            Console.WriteLine();
            Console.WriteLine(new string('=', m_s_Size * 4 + 2));

            for (int row = 0; row < m_s_Size; row++)
            {
                char rowLabel = (char)('A' + row);
                Console.Write($"{rowLabel}|");

                for (int col = 0; col < m_s_Size; col++)
                {
                    if (m_s_Pieces[row, col] == null)
                    {
                        Console.Write("   |");
                    }
                    else
                    {
                        Console.Write($" {m_s_Pieces[row, col].GetSymbol()} |");
                    }
                }

                Console.WriteLine();
                Console.WriteLine(new string('=', m_s_Size * 4 + 2));
            }
        }

        // $G$ CSS-006 (-3) Missing blank line, after "if / else" blocks.
        private static int PromoteToKingIfNeeded(Position i_To, Player i_Player)
        {
            int lastRow = (i_Player.GetSymbol() == 'O') ? m_s_Size - 1 : 0;
            if(i_To != null && i_To.GetRow() == lastRow)
            {
                return (i_Player.GetSymbol() == 'O') ? 0 : 1;
            }
            return 2;
        }

        public void MovePiece(Position i_From, Position i_To,Player i_Player)  
        {                                                             
            if (i_Player.GetSymbol()=='X')
            {
                if (m_s_Pieces[i_From.GetRow(), i_From.GetColumn()].GetSymbol() == 'K')
                {
                    m_s_Pieces[i_To.GetRow(), i_To.GetColumn()].SetSymbol('K');
                    m_s_Pieces[i_From.GetRow(), i_From.GetColumn()].SetSymbol(' ');

                }
                else
                {
                    m_s_Pieces[i_From.GetRow(), i_From.GetColumn()].SetSymbol(' ');
                    if (Board.PromoteToKingIfNeeded(i_To, i_Player) == 1)
                    {
                        m_s_Pieces[i_To.GetRow(), i_To.GetColumn()].SetSymbol('K');
                    }

                    else
                    {
                        m_s_Pieces[i_To.GetRow(), i_To.GetColumn()].SetSymbol('X');
                    }
                }
            }
            else
            {
                if (m_s_Pieces[i_From.GetRow(), i_From.GetColumn()].GetSymbol() == 'U')
                {
                    m_s_Pieces[i_To.GetRow(), i_To.GetColumn()].SetSymbol('U');
                    m_s_Pieces[i_From.GetRow(), i_From.GetColumn()].SetSymbol(' ');
                }
                else
                {
                    m_s_Pieces[i_From.GetRow(), i_From.GetColumn()].SetSymbol(' ');
                    if (Board.PromoteToKingIfNeeded(i_To, i_Player) == 0)
                    {
                        m_s_Pieces[i_To.GetRow(), i_To.GetColumn()].SetSymbol('U');
                    }
                    else
                    {
                        m_s_Pieces[i_To.GetRow(), i_To.GetColumn()].SetSymbol('O');
                    }
                }
            }
        }

        public static void UpdateBoardForEatingMove(Position i_StartPos, Position i_EndPos)
        {
            Piece[,] ezerPiece = Board.GetPieceMatrix();
            int eatenRow = (i_StartPos.GetRow() + i_EndPos.GetRow()) / 2;
            int eatenCol = (i_StartPos.GetColumn() + i_EndPos.GetColumn()) / 2;
            ezerPiece[eatenRow, eatenCol].SetSymbol(' ');
            Console.WriteLine($"Piece at {eatenRow}, {eatenCol} was eaten."); 
        }

        public static bool CanContinueEatingFrom(Position i_Position, char i_PlayerSymbol, char i_PlayerKingSymbol)
        {
            int[][] directions;
            Piece[,] ezerMatrix = Board.GetPieceMatrix();
            if (ezerMatrix[i_Position.GetRow(),i_Position.GetColumn()].GetSymbol() == i_PlayerKingSymbol)
            {
                directions = new int[][]
                {
                    new int[] { -2, -2 }, 
                    new int[] { -2, 2 },  
                    new int[] { 2, -2 },  
                    new int[] { 2, 2 }    
                };
            }
            else if (i_PlayerSymbol == 'X')
            {
                directions = new int[][]
                {
                     new int[] { -2, -2 }, 
                     new int[] { -2, 2 }   
                };
            }
            else
            {
                directions = new int[][]
                {
                    new int[] { 2, -2 },  
                    new int[] { 2, 2 }    
                };
            }

            foreach (var direction in directions)
            {
                int newRow = i_Position.GetRow() + direction[0];
                int newCol = i_Position.GetColumn() + direction[1];
                int middleRow = i_Position.GetRow() + direction[0] / 2;
                int middleCol = i_Position.GetColumn() + direction[1] / 2;

                if (IsWithinBounds(newRow, newCol) &&
                    m_s_Pieces[middleRow, middleCol].GetSymbol() != i_PlayerSymbol &&
                    m_s_Pieces[middleRow, middleCol].GetSymbol() != i_PlayerKingSymbol &&
                    m_s_Pieces[middleRow, middleCol].GetSymbol() != ' ' && 
                    m_s_Pieces[newRow, newCol]?.GetSymbol() == ' ') 
                {
                    return true;
                }
            }

            return false;
        }

        // $G$ CSS-999 (-8) Private methods should start with a lowercase letter.
        private static bool IsWithinBounds(int i_Row, int i_Col)
        {
            return i_Row >= 0 && i_Row < m_s_Size && i_Col >= 0 && i_Col < m_s_Size;
        }

        public static Piece[,] GetPieceMatrix()
        {
            return m_s_Pieces;
        }
    }
}
