﻿using System;

namespace CheckersGame
{
    // $G$ CSS-003 (-3) Bad readonly members variable name (should be in the form of r_PamelCase).
    public class Player
    {
        private readonly string m_r_Name;
        private char m_Symbol;
        private int m_Score; 
       
        public Player(string i_Name, char i_Symbol)
        {
            m_r_Name = i_Name;
            m_Symbol = i_Symbol;
            m_Score = 0; 
        }
    
        public static bool ValidationName(string i_CheckName)
        {
            return(i_CheckName.Length > 20) || (i_CheckName.Contains(" ") || String.IsNullOrEmpty(i_CheckName));      
        }

        public string GetName()
        {
            return m_r_Name;
        }

        public char GetSymbol()
        {
            return m_Symbol;
        }

        public int GetScore()
        {
            return m_Score;
        }

        public void UpdateScore(int i_ScoreToAdd)
        {
            m_Score += i_ScoreToAdd;
        }
    }
}
