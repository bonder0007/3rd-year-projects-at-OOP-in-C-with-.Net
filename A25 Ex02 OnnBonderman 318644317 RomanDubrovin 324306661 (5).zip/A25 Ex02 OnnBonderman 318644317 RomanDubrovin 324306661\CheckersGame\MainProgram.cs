﻿// $G$ SFN-013 (-3) You should reset the scores when user ask to play another game round
// $G$ RUL-005 (-20) Wrong zip folder structure
// $G$ RUL-006 (-40) Late submission - 1 day.
// $G$ CSS-027 (-3) Spaces are not kept as required.
namespace CheckersGame
{
    // $G$ DSN-006 (-5) Main method should be in class named Program !

    public static class MainProgram
    {

        public static void Main(string[] args)
        {
            ConsoleUI.StartGameUI();
        }
    }

}
