﻿using CheckersGame;
using System;
using System.Collections.Generic;

// $G$ CSS-004 (-5) Bad static members variable name (should be in the form of s_PascalCase).
public class GameManager
{
    private static Board m_s_Board;
    private static Player[] m_s_Players;
    private int m_CurrentPlayerIndex;
    private bool m_IsGameOver;
    private static bool m_s_IsVsComputer;
    private Position m_LastEaterPosition = null;
    public static Player[] GetPlayers()
    {
        return m_s_Players;
    }

    public static bool GetIsVsComputer()
    {
        return m_s_IsVsComputer;
    }

    // $G$ DSN-008 (-5) Bad Encapsulation.
    // $G$ DSN-003 (-5) This method is too long. The code should be divided to logical methods
    // $G$ DSN-002 (-10) You should not make UI calls from your logic classes. 
    public void StartGameLogical(int i_BoardSize, Player[] i_Players, bool i_IsVsComputer)
    {
        m_s_Board = new Board(i_BoardSize);
        m_s_Players = i_Players;
        m_CurrentPlayerIndex = 0;
        m_IsGameOver = false;
        bool IsThereAnyMovesLeft;
        m_s_IsVsComputer = i_IsVsComputer;
        m_s_Board.Initialize();
        List<Move> PossibleEatingMoves;

        while (!m_IsGameOver)
        {
            char playerKingSymbol = (m_s_Players[m_CurrentPlayerIndex].GetSymbol() == 'O') ? 'U' : 'K';
            Player currentPlayer = m_s_Players[m_CurrentPlayerIndex];
            bool mustContinueEating = m_LastEaterPosition != null;
            bool isValidMove = false;
            List<Player> PlayersWithoutMovesLeft = new List<Player>();

            do
            {
                if (mustContinueEating)  
                {
                    Console.WriteLine($"{currentPlayer.GetName()}, you must continue eating with the same piece!");
                }

                for (int index = 0; index < m_s_Players.Length; index++)
                {
                    IsThereAnyMovesLeft = Board.CheckIfThereAreMovesLeft(m_s_Board, m_s_Players[index]);
                    if (IsThereAnyMovesLeft == true)
                    {
                        Player ezerPlayer= new Player(m_s_Players[index].GetName(), m_s_Players[index].GetSymbol());
                        PlayersWithoutMovesLeft.Add(ezerPlayer);
                    }
                }

                if(PlayersWithoutMovesLeft.Count == 2)
                {
                    Console.WriteLine("its a DRAW!!!");
                    CalcScore(i_Players, '?');
                    ConsoleUI.EndGame();
                }
                else if(PlayersWithoutMovesLeft.Count == 1)
                {
                    Console.WriteLine("{0} you lost ! ",PlayersWithoutMovesLeft[0].GetName());
                    CalcScore(i_Players, PlayersWithoutMovesLeft[0].GetSymbol());
                    ConsoleUI.EndGame();
                }

                PossibleEatingMoves = Board.checkIfPossibleEatingMoves(m_s_Board, currentPlayer.GetSymbol());
                if(!GameManager.GetIsVsComputer() || 
                   (GameManager.GetIsVsComputer() && currentPlayer.GetSymbol() == 'X'))
                {
                    Move.printEatingMoves(PossibleEatingMoves);
                }
                
                Move currentMove;
                if (GameManager.GetIsVsComputer() && playerKingSymbol == 'U')
                {
                    currentMove = GameManager.StartComputerMove();
                }
                else
                {
                    currentMove = ConsoleUI.GetPlayerMove(currentPlayer, m_s_Board, m_LastEaterPosition);
                }
                
                if (currentMove == null)
                {
                    m_IsGameOver = true;
                    break;
                }

                if (PossibleEatingMoves.Count != 0)
                {
                    Position ezerpositionFrom = currentMove.GetFrom();
                    Position ezerpositionTo = currentMove.GetTo();
                    isValidMove = false;

                    for (int index = 0; index < PossibleEatingMoves.Count; index++)
                    {
                        if (PossibleEatingMoves[index].GetFrom().Equals(ezerpositionFrom) &&
                            PossibleEatingMoves[index].GetTo().Equals(ezerpositionTo))
                        {
                            isValidMove = true;  
                            break;
                        }

                    }

                    if (!isValidMove) 
                    {
                        Console.WriteLine("Invalid move! You must make an eating move from the list of possible moves.");
                        continue;
                    }
                }
            
                if (Math.Abs(currentMove.GetFrom().GetRow() - currentMove.GetTo().GetRow()) == 2) 
                {
                    if (mustContinueEating && !currentMove.GetFrom().Equals(m_LastEaterPosition))  
                    {
                        Console.WriteLine("Invalid move! You must continue eating with the same piece.");
                        continue; 
                    }

                    m_s_Board.MovePiece(currentMove.GetFrom(), currentMove.GetTo(), currentPlayer);
                    Board.UpdateBoardForEatingMove(currentMove.GetFrom(), currentMove.GetTo());

                    if (Board.CanContinueEatingFrom(currentMove.GetTo(), currentPlayer.GetSymbol(), playerKingSymbol)) 
                    {
                        m_LastEaterPosition = currentMove.GetTo(); 
                        mustContinueEating = true;
                    }
                    else
                    {
                        m_LastEaterPosition = null; 
                        mustContinueEating = false;
                    }

                    isValidMove = true;
                }
                else if (mustContinueEating)
                {
                    Console.WriteLine("Invalid move! You must continue eating.");
                    mustContinueEating = true; 
                }
                else
                { 
                    m_s_Board.MovePiece(currentMove.GetFrom(), currentMove.GetTo(), currentPlayer);
                    m_LastEaterPosition = null;
                    mustContinueEating = false;
                    isValidMove = true;
                }

                m_s_Board.PrintBoard();
                Console.Write("{0}'s move was ({1}) :",
                m_s_Players[m_CurrentPlayerIndex].GetName(),
                m_s_Players[m_CurrentPlayerIndex].GetSymbol());

                Position.PrintPositionInLetters(currentMove.GetFrom());
                Console.Write(">");
                Position.PrintPositionInLetters(currentMove.GetTo());
                Console.WriteLine();
            }
            while (mustContinueEating || !isValidMove);

            if (!mustContinueEating) 
            {
                m_CurrentPlayerIndex = (m_CurrentPlayerIndex + 1) % 2;
            }
        }
    }

    // $G$ DSN-008 (-5) There is no good reason to define this method as public.
    public static Move StartComputerMove()
    {
        List<Move> eatingMovesForComputer = new List<Move>();
        List<Move> legalMovesForComputer = new List<Move>();
        Console.WriteLine("Computer’s Turn (press ‘enter’ to see it’s move)");
        string ContinueWithComputerMove = Console.ReadLine();

        while(!String.IsNullOrEmpty(ContinueWithComputerMove))
        {
            Console.WriteLine("Invalid Input ! just press enter to see Computer's next move");
            ContinueWithComputerMove = Console.ReadLine();
        }

        return CollectComputerMoves(eatingMovesForComputer, legalMovesForComputer);
    }

    private static Move CollectComputerMoves(List<Move> i_EatingMovesForComputer, List<Move> i_LegalMovesForComputer)
    {
        char ComputerSymbol = m_s_Players[1].GetSymbol();
        char ComputerkingSymbol = (m_s_Players[1].GetSymbol() == 'X') ? 'K' : 'U';
        i_EatingMovesForComputer = Board.checkIfPossibleEatingMoves(m_s_Board, ComputerSymbol);
        i_LegalMovesForComputer = new List<Move>();
        Piece[,] ezerMatrixPiece = Board.GetPieceMatrix();

        for(int row = 0; row < Board.GetSize(); row++)
        {
            for(int col = 0; col < Board.GetSize(); col++)
            {
                if ((ezerMatrixPiece[row, col].GetSymbol() == ComputerSymbol) ||
                     ezerMatrixPiece[row, col].GetSymbol() == ComputerkingSymbol)
                {
                    Position ezerCurrentPosToCheck = new Position(row, col);
                    List<Move> ezerLegalListMove = Board.GetLegalMovesForPosition(ezerCurrentPosToCheck);
                    if(ezerLegalListMove != null)
                    {
                        i_LegalMovesForComputer.AddRange(ezerLegalListMove);
                    }
                }
            }
        }

        return ChooseComputerMove(i_EatingMovesForComputer, i_LegalMovesForComputer);
    }

    // $G$ CSS-013 (-5) Bad parameter name (should be in the form of i_PascalCase).
    private static Move ChooseComputerMove(List<Move> i_EatingMovesComputer, List<Move> i_legalMovesComputer)
    {
        if(i_EatingMovesComputer.Count != 0)
        {
            int randomIndex = GetRandomNumber(i_EatingMovesComputer.Count);
            return i_EatingMovesComputer[randomIndex];
        }
        else if(i_legalMovesComputer.Count != 0)
        {
            int randomIndex = GetRandomNumber(i_legalMovesComputer.Count);
            return i_legalMovesComputer[randomIndex];
        }
        else
        {
            return null;
        }
    }

    // $G$ NTT-007 (-5) There's no need to re-instantiate the Random instance each time it is used.
    internal static int GetRandomNumber(int maxIndex)
    {
        Random random = new Random();
        // $G$ CSS-027 (-1) Missing blank line.
        return random.Next(0, maxIndex);
    }

    public static void CalcScore(Player[] i_Players, char i_QuitedLostPlayerSymbol)
    {
        bool IsDraw = false;

        if(i_QuitedLostPlayerSymbol == '?')
        {
            IsDraw = true;
        }

        if (IsDraw == false)
        {
            int FirstPlayerScore = 0, SecondPlayerScore = 0, FirstPlayerdifferenceScore = 0, SecondPlayerdifferenceScore = 0;
            Piece[,] FinalMatrix = Board.GetPieceMatrix();
            for (int row = 0; row < Board.GetSize(); row++)
            {
                for (int col = 0; col < Board.GetSize(); col++)
                {
                    if (FinalMatrix[row, col].GetSymbol() == i_Players[0].GetSymbol())
                    {
                        FirstPlayerScore++;
                    }

                    if (FinalMatrix[row, col].GetSymbol() == 'K')
                    {
                        FirstPlayerScore += 4;
                    }

                    if (FinalMatrix[row, col].GetSymbol() == i_Players[1].GetSymbol())
                    {
                        SecondPlayerScore++;
                    }

                    if (FinalMatrix[row, col].GetSymbol() == 'U')
                    {
                        SecondPlayerScore += 4;
                    }
                }
            }

            if (i_QuitedLostPlayerSymbol == 'X')
            {
                SecondPlayerdifferenceScore = Math.Abs(FirstPlayerScore - SecondPlayerScore);
                i_Players[1].UpdateScore(SecondPlayerdifferenceScore);
            }
            else
            {
                FirstPlayerdifferenceScore = Math.Abs(FirstPlayerScore - SecondPlayerScore);
                i_Players[0].UpdateScore(FirstPlayerdifferenceScore);
            }

            GameManager.PrintScore(FirstPlayerdifferenceScore, SecondPlayerdifferenceScore);
        }
    }

    public static void PrintScore(int i_FirstPlayerScore, int i_SecondPlayerScore)
    {
        foreach (var CurrentPlayer in m_s_Players)
        {
            Console.WriteLine("{0}'s score is: {1}", CurrentPlayer.GetName(), CurrentPlayer.GetScore());
        }
    }
}
